import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = { title: "まなびログ", description: "日々の学習時間を記録して振り返る。" };

export default function Layout({ children }: { children: React.ReactNode }) {
  return <html lang="ja"><body>{children}</body></html>;
}
