import { cookies } from "next/headers";
import { desc, eq } from "drizzle-orm";
import { getDb } from "../db";
import { records } from "../db/schema";

const messages: Record<string, string> = {
  saved: "学習記録を保存しました。",
  deleted: "学習記録を削除しました。",
  invalid: "入力内容を確認してください。学習時間は1〜1440分です。",
  failed: "保存処理に失敗しました。時間をおいて再度お試しください。",
};

export default async function Page({ searchParams }: { searchParams: Promise<{status?: string}> }) {
  const owner = (await cookies()).get("study_owner")?.value;
  const entries = owner ? await getDb().select().from(records).where(eq(records.owner, owner)).orderBy(desc(records.day), desc(records.id)) : [];
  const total = entries.reduce((sum, entry) => sum + entry.minutes, 0);
  const bySubject = new Map<string, number>();
  for (const entry of entries) bySubject.set(entry.subject, (bySubject.get(entry.subject) ?? 0) + entry.minutes);
  const subjects = [...bySubject.entries()].sort((a, b) => b[1] - a[1]);
  const today = new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Tokyo", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
  const { status } = await searchParams;
  return <main>
    <header className="hero">
      <div><h1>まなびログ</h1><p>日々の学習時間を記録して振り返る。</p></div>
      <dl className="stats">
        <div><dt>合計学習時間</dt><dd>{total.toLocaleString("ja-JP")}<small> 分</small></dd></div>
        <div><dt>記録した回数</dt><dd>{entries.length}<small> 回</small></dd></div>
      </dl>
    </header>
    {status && Object.hasOwn(messages, status) && <p className="notice" role="status">{messages[status]}</p>}
    <div className="dashboard">
      <section className="card">
        <h2>学習を記録</h2>
        <form action="/records" method="post">
          <label>科目<input name="subject" maxLength={40} required placeholder="例 英語" /></label>
          <div className="fields">
            <label>学習日<input type="date" name="day" defaultValue={today} min="1900-01-01" required /></label>
            <label>時間（分）<input type="number" name="minutes" min={1} max={1440} required placeholder="45" /></label>
          </div>
          <label>メモ（任意）<textarea name="memo" maxLength={200} rows={3} placeholder="取り組んだ内容" /></label>
          <button className="primary">記録を保存</button>
        </form>
      </section>
      <section className="card">
        <h2>科目別の学習時間</h2>
        {subjects.length ? <ul className="subjects">{subjects.map(([name, minutes]) =>
          <li key={name}><div><span>{name}</span><strong>{minutes} 分</strong></div>
          <progress aria-label={name + "の学習時間の割合"} value={minutes} max={total} /></li>)}</ul>
          : <p className="empty">記録を追加すると、科目別の内訳が表示されます。</p>}
      </section>
    </div>
    <section className="card history">
      <h2>学習履歴</h2>
      {entries.length ? <ul>{entries.map(entry => <li key={entry.id}>
        <div><time dateTime={entry.day}>{entry.day.replaceAll("-", "/")}</time><h3>{entry.subject}</h3>
          {entry.memo && <p>{entry.memo}</p>}</div>
        <div className="record-actions"><strong>{entry.minutes} 分</strong>
          <form action="/records" method="post">
            <input type="hidden" name="action" value="delete" />
            <input type="hidden" name="id" value={entry.id} />
            <button className="delete" aria-label={entry.day + "の" + entry.subject + "の記録を削除"}>削除</button>
          </form></div>
      </li>)}</ul> : <p className="empty">学習履歴はまだありません。</p>}
    </section>
    <footer>学習記録は同じブラウザーから確認できます。</footer>
  </main>;
}
