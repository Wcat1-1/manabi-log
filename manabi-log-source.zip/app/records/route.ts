import { cookies } from "next/headers";
import { and, eq } from "drizzle-orm";
import { getDb } from "../../db";
import { records } from "../../db/schema";

export async function POST(request: Request) {
  const url = new URL(request.url);
  const redirect = (status: string) => new Response(null, {
    status: 303, headers: { Location: "/?status=" + status },
  });
  if (request.headers.get("origin") !== url.origin &&
      request.headers.get("sec-fetch-site") !== "same-origin") {
    return new Response("Forbidden", { status: 403 });
  }
  if (!request.headers.get("content-type")?.startsWith("application/x-www-form-urlencoded")) {
    return redirect("invalid");
  }
  const body = await request.text();
  if (body.length > 8192) return redirect("invalid");
  const form = new URLSearchParams(body);
  const jar = await cookies();
  const owner = jar.get("study_owner")?.value || crypto.randomUUID();

  try {
    if (form.get("action") === "delete") {
      const id = form.get("id") ?? "";
      await getDb().delete(records).where(and(eq(records.owner, owner), eq(records.id, id)));
      return redirect("deleted");
    }
    const subject = form.get("subject")?.trim() ?? "";
    const day = form.get("day") ?? "";
    const minutes = Number(form.get("minutes"));
    const memo = form.get("memo")?.trim() ?? "";
    const parsed = new Date(day + "T00:00:00Z");
    if (!subject || subject.length > 40 || memo.length > 200 ||
        !/^\d{4}-\d{2}-\d{2}$/.test(day) || !Number.isFinite(parsed.getTime()) ||
        parsed.toISOString().slice(0, 10) !== day || day < "1900-01-01" ||
        !Number.isInteger(minutes) || minutes < 1 || minutes > 1440) {
      return redirect("invalid");
    }
    await getDb().insert(records).values({ id: crypto.randomUUID(), owner, subject, day, minutes, memo });
    jar.set("study_owner", owner, { httpOnly: true, secure: url.protocol === "https:", sameSite: "lax", path: "/", maxAge: 31536000 });
    return redirect("saved");
  } catch (error) {
    console.error("Study record update failed", error);
    return redirect("failed");
  }
}
