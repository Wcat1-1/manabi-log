CREATE TABLE `study_records` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`subject` text NOT NULL,
	`day` text NOT NULL,
	`minutes` integer NOT NULL,
	`memo` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `study_records_owner_day` ON `study_records` (`owner`,`day`);