import { index, integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const records = sqliteTable("study_records", {
  id: text("id").primaryKey(),
  owner: text("owner").notNull(),
  subject: text("subject").notNull(),
  day: text("day").notNull(),
  minutes: integer("minutes").notNull(),
  memo: text("memo").notNull(),
}, (table) => [index("study_records_owner_day").on(table.owner, table.day)]);
